#!/bin/bash
set -e

if [ -z $CI_PROJECT_PATH ]
then
  echo "CI_PROJECT_PATH env var not set"
  exit 1
fi

if [ -z $GIT_COMMITTER_NAME ]
then
  echo "GIT_COMMITTER_NAME env var not set"
  exit 1
fi

if [ -z $GIT_COMMITTER_EMAIL ]
then
  echo "GIT_COMMITTER_EMAIL env var not set"
  exit 1
fi

if [ -z $GIT_OAUTH_TOKEN ]
then
  echo "GIT_OAUTH_TOKEN env var not set"
  exit 1
fi

git config --global user.email $GIT_COMMITTER_EMAIL
git config --global user.name $GIT_COMMITTER_NAME
git remote set-url origin https://oauth2:${GIT_OAUTH_TOKEN}@gitlab.corp.paymaya.com/${CI_PROJECT_PATH}.git
