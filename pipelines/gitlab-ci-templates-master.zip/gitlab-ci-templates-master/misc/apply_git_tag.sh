#!/bin/bash
set -e

if [ -z $CI_COMMIT_REF_NAME ]
then
  echo "CI_COMMIT_REF_NAME env var not set"
  exit 1
fi

if [ -z $CI_COMMIT_SHORT_SHA ]
then
  echo "CI_COMMIT_SHORT_SHA env var not set"
  exit 1
fi

if [ -z $1 ]
then
  echo "Git tag was not provided"
  exit 1
fi

sh /shared-scripts/setup_gitlab_user.sh

git_tag=$1

message="Tagging with: $git_tag"
echo $message

git checkout $CI_COMMIT_REF_NAME
git tag -a "$git_tag" $CI_COMMIT_SHORT_SHA -m "$message"
git push --tags
