# gitlab-ci-templates

gitlab-ci templates for pbm repositories